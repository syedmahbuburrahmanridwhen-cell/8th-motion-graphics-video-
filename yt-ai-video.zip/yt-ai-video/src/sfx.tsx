import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { SCENES } from "./timing";
import { SFX_ENABLED } from "./config";
import type { SfxEvent, SfxName } from "./sfxTypes";
import { hookSfx } from "./scenes/Hook";
import { phoneSfx } from "./scenes/PhoneScene";
import { carouselSfx } from "./scenes/CarouselScene";
import { stepsSfx } from "./scenes/StepsScene";
import { trySfx } from "./scenes/TryScene";
import { followSfx } from "./scenes/FollowScene";
import { premiumSfx } from "./scenes/PremiumScene";
import { outroSfx } from "./scenes/OutroScene";

// clip lengths (seconds) — measured by scripts/make-sfx.mjs
const LEN: Record<SfxName, number> = { pop: 0.26, click: 0.14, whoosh: 0.69, whoosh_soft: 0.44, chime: 0.5, thud: 0.3 };

// scene transitions: one smooth whoosh per wipe, peak lands on the cut
const transitionSfx: SfxEvent[] = SCENES.slice(1).map((s, i) => ({
  frame: s.from - 9,
  name: "whoosh" as const,
  volume: 0.27 + (i % 2) * 0.03,
  rate: [1, 0.95, 1.05, 0.97, 1.03, 0.94, 1.04][i % 7],
}));

export const SFX_EVENTS: SfxEvent[] = [
  ...hookSfx, ...phoneSfx, ...carouselSfx, ...stepsSfx, ...trySfx, ...followSfx, ...premiumSfx, ...outroSfx, ...transitionSfx,
].sort((a, b) => a.frame - b.frame);

export const Sfx: React.FC = () => {
  if (!SFX_ENABLED) return null;
  return (
    <>
      {SFX_EVENTS.map((e, i) => (
        <Sequence key={i} from={Math.max(0, e.frame)} durationInFrames={Math.ceil(LEN[e.name] * 30 / (e.rate ?? 1)) + 3}>
          <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.volume} playbackRate={e.rate ?? 1} />
        </Sequence>
      ))}
    </>
  );
};

export type SfxName = "pop" | "click" | "whoosh" | "whoosh_soft" | "chime" | "thud";
export type SfxEvent = { frame: number; name: SfxName; volume: number; rate?: number };

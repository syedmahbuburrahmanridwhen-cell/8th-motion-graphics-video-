// Project-wide switches. Everything else is derived from the SRT (see timing.ts).
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// public/voiceover.mp3 (optional). If the file is missing it is silently skipped.
export const VOICEOVER_IN_PREVIEW = true; // plays in Remotion Studio
export const VOICEOVER_IN_RENDER = false; // set true to mix the voiceover into the MP4 as well
export const VOICEOVER_FILE = "voiceover.mp3";

// SFX master switch (Studio preview + render)
export const SFX_ENABLED = true;

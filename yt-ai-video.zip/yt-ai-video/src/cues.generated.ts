// AUTO-GENERATED from public/script.srt by scripts/srt-to-cues.mjs — do not edit by hand
export type Cue = { index: number; start: number; end: number; text: string };
export const CUES: Cue[] = [
  {
    "index": 1,
    "start": 0.12,
    "end": 2.68,
    "text": "ভাই, AI দিয়ে ভিডিও বানাতে গিয়ে তো অনেক"
  },
  {
    "index": 2,
    "start": 2.68,
    "end": 5.34,
    "text": "paid website বা app try করেছেন। এবার"
  },
  {
    "index": 3,
    "start": 5.34,
    "end": 6.04,
    "text": "এটা দেখেছেন কি?"
  },
  {
    "index": 4,
    "start": 7,
    "end": 9.2,
    "text": "আপনি চাইলে সরাসরি আপনার ফোনের YouTube"
  },
  {
    "index": 5,
    "start": 9.2,
    "end": 11.72,
    "text": "app থেকেই একদম free-te চমৎকার সব"
  },
  {
    "index": 6,
    "start": 11.72,
    "end": 13.8,
    "text": "ভিডিও বানিয়ে নিতে পারবেন। শুধু ভিডিওই"
  },
  {
    "index": 7,
    "start": 13.8,
    "end": 16.72,
    "text": "না, চমৎকার photo to video এবং নিজের মনের"
  },
  {
    "index": 8,
    "start": 16.72,
    "end": 18.76,
    "text": "মতো music-o তৈরি করতে পারবেন কোনো"
  },
  {
    "index": 9,
    "start": 18.76,
    "end": 21.1,
    "text": "ঝামেলা ছাড়াই। এটার জন্য YouTube app-e"
  },
  {
    "index": 10,
    "start": 21.1,
    "end": 22.92,
    "text": "গিয়ে নিচের plus icon-e click করে"
  },
  {
    "index": 11,
    "start": 22.92,
    "end": 25.42,
    "text": "shorts-e যান। এরপর ওপরে থাকা star"
  },
  {
    "index": 12,
    "start": 25.42,
    "end": 27.54,
    "text": "icon-e click করলেই video, photo to"
  },
  {
    "index": 13,
    "start": 27.54,
    "end": 29.42,
    "text": "video এবং music তৈরির option পেয়ে"
  },
  {
    "index": 14,
    "start": 29.42,
    "end": 32.54,
    "text": "যাবেন। দেরি না করে এখনই try করুন। এমন"
  },
  {
    "index": 15,
    "start": 32.54,
    "end": 34.6,
    "text": "আরও অস্থির tech tips পেতে আমার channel"
  },
  {
    "index": 16,
    "start": 34.6,
    "end": 36.84,
    "text": "বা page-ti follow করে রাখুন। আর আপনার"
  },
  {
    "index": 17,
    "start": 36.84,
    "end": 39.16,
    "text": "কোনো creator বন্ধুর উপকারে আসলে ভিডিওটি"
  },
  {
    "index": 18,
    "start": 39.16,
    "end": 41.34,
    "text": "অবশ্যই share করুন। আর যারা নিজেদের"
  },
  {
    "index": 19,
    "start": 41.34,
    "end": 43.22,
    "text": "personal business বা brand-er জন্য"
  },
  {
    "index": 20,
    "start": 43.22,
    "end": 45.52,
    "text": "premium website বা app বানাতে চান, তারা"
  },
  {
    "index": 21,
    "start": 45.52,
    "end": 47.82,
    "text": "আমার সাথে যোগাযোগ করতে পারেন। ধন্যবাদ।"
  }
];

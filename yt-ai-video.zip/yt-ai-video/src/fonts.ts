// Offline fonts: files live in public/fonts, loaded with the FontFace API.
import { useEffect, useState } from "react";
import { continueRender, delayRender, staticFile } from "remotion";

const BENGALI = "U+0951-0952,U+0964-0965,U+0980-09FE,U+1CF7,U+200C-200D,U+20B9,U+25CC";
const LATIN =
  "U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-200B,U+200E-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD";

const FILES: { weight: number; subset: "bengali" | "latin" }[] = [500, 600, 700].flatMap((weight) => [
  { weight, subset: "bengali" as const },
  { weight, subset: "latin" as const },
]);

let promise: Promise<void> | null = null;

export const loadFonts = (): Promise<void> => {
  if (promise) return promise;
  promise = Promise.all(
    FILES.map(async ({ weight, subset }) => {
      const face = new FontFace(
        "Hind Siliguri",
        `url(${staticFile(`fonts/hind-siliguri-${subset}-${weight}-normal.woff2`)}) format('woff2')`,
        { weight: String(weight), unicodeRange: subset === "bengali" ? BENGALI : LATIN }
      );
      await face.load();
      document.fonts.add(face);
    })
  ).then(() => undefined);
  return promise;
};

export const useFontsReady = () => {
  // call once at the root; holds the render until fonts are decoded
  const [handle] = useState(() => delayRender("fonts"));
  useEffect(() => {
    loadFonts()
      .catch((e) => console.error("font load failed", e))
      .finally(() => continueRender(handle));
  }, [handle]);
};

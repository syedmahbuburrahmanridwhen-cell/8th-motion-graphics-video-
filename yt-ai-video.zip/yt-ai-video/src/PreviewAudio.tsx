import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_FILE, VOICEOVER_IN_PREVIEW, VOICEOVER_IN_RENDER } from "./config";

/**
 * Plays public/voiceover.mp3 if (and only if) the file exists.
 * - Studio preview: controlled by VOICEOVER_IN_PREVIEW
 * - Final render:   controlled by VOICEOVER_IN_RENDER (default off)
 * A missing file is skipped silently.
 */
export const PreviewAudio: React.FC = () => {
  const { isRendering } = getRemotionEnvironment();
  const enabled = isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_PREVIEW;
  const [handle] = useState(() => (enabled ? delayRender("voiceover check") : null));
  const [exists, setExists] = useState(false);

  useEffect(() => {
    if (!enabled || handle === null) return;
    let alive = true;
    fetch(staticFile(VOICEOVER_FILE), { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        if (alive && r.ok && !type.includes("text/html")) setExists(true);
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => { alive = false; };
  }, [enabled, handle]);

  if (!enabled || !exists) return null;
  return <Audio src={staticFile(VOICEOVER_FILE)} volume={1} />;
};

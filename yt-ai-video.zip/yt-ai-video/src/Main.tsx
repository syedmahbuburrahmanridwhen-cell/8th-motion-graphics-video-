import React from "react";
import { AbsoluteFill, interpolate, Sequence, useCurrentFrame } from "remotion";
import { theme } from "./theme";
import { useFontsReady } from "./fonts";
import { SCENES, OVERLAP } from "./timing";
import { BgMesh, Grade, Grain, Vignette, Wipe } from "./components/layers";
import { Hook } from "./scenes/Hook";
import { PhoneScene } from "./scenes/PhoneScene";
import { CarouselScene } from "./scenes/CarouselScene";
import { StepsScene } from "./scenes/StepsScene";
import { TryScene } from "./scenes/TryScene";
import { FollowScene } from "./scenes/FollowScene";
import { PremiumScene } from "./scenes/PremiumScene";
import { OutroScene } from "./scenes/OutroScene";
import { Sfx } from "./sfx";
import { PreviewAudio } from "./PreviewAudio";

const COMPONENTS: Record<string, React.FC> = {
  hook: Hook, phone: PhoneScene, carousel: CarouselScene, steps: StepsScene,
  try: TryScene, follow: FollowScene, premium: PremiumScene, outro: OutroScene,
};

/** exits are quicker than entrances: the scene lifts away just before the wipe covers it */
const SceneExit: React.FC<{ duration: number; last: boolean; children: React.ReactNode }> = ({ duration, last, children }) => {
  const frame = useCurrentFrame();
  if (last) return <AbsoluteFill>{children}</AbsoluteFill>;
  const start = duration - OVERLAP - 9;
  const p = interpolate(frame, [start, start + 9], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: theme.ease.in });
  return <AbsoluteFill style={{ opacity: 1 - p, transform: `translateY(${-26 * p}px) scale(${1 - 0.025 * p})` }}>{children}</AbsoluteFill>;
};

export const Main: React.FC = () => {
  useFontsReady();
  return (
    <AbsoluteFill style={{ background: theme.colors.bg, fontFamily: theme.fonts.main }}>
      <BgMesh />
      {SCENES.map((s, i) => {
        const C = COMPONENTS[s.id];
        return (
          <Sequence key={s.id} from={s.from} durationInFrames={s.duration} name={s.id}>
            <SceneExit duration={s.duration} last={i === SCENES.length - 1}><C /></SceneExit>
          </Sequence>
        );
      })}
      {SCENES.slice(1).map((s, i) => (
        <Wipe key={s.id} center={s.from} dir={i % 2 === 0 ? 1 : -1} />
      ))}
      <Grade />
      <Grain />
      <Vignette />
      <PreviewAudio />
      <Sfx />
    </AbsoluteFill>
  );
};

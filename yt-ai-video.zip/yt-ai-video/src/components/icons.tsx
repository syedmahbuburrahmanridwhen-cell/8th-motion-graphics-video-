import React from "react";

type P = { size?: number; color?: string; stroke?: number; style?: React.CSSProperties };
const base = (size: number, style?: React.CSSProperties) => ({
  width: size, height: size, viewBox: "0 0 24 24", fill: "none", style,
  strokeLinecap: "round" as const, strokeLinejoin: "round" as const,
});

export const PlusIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 2.6, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}><path d="M12 4.5v15M4.5 12h15" /></svg>
);
export const SparkleIcon: React.FC<P> = ({ size = 48, color = "currentColor", style }) => (
  <svg {...base(size, style)} fill={color}>
    <path d="M12 2C12.8 7.6 16.4 11.2 22 12C16.4 12.8 12.8 16.4 12 22C11.2 16.4 7.6 12.8 2 12C7.6 11.2 11.2 7.6 12 2Z" />
  </svg>
);
export const PlayIcon: React.FC<P> = ({ size = 48, color = "currentColor", style }) => (
  <svg {...base(size, style)} fill={color}><path d="M8 5.2v13.6a.8.8 0 0 0 1.2.7l10.8-6.8a.8.8 0 0 0 0-1.4L9.2 4.5A.8.8 0 0 0 8 5.2Z" /></svg>
);
export const ImageIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 1.8, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}>
    <rect x="3" y="4" width="18" height="16" rx="3.2" /><circle cx="9" cy="10" r="1.8" /><path d="M4 18l5-5 4 4 3-3 4 4" />
  </svg>
);
export const MusicIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 1.9, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}>
    <path d="M9 18V6.2l10-2V16" /><circle cx="6.8" cy="18" r="2.3" /><circle cx="16.8" cy="16" r="2.3" />
  </svg>
);
export const LockIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 2, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}>
    <rect x="5" y="11" width="14" height="9.5" rx="2.6" /><path d="M8 11V8a4 4 0 0 1 8 0v3" />
  </svg>
);
export const CheckIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 2.8, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}><path d="M5 12.5l4.6 4.6L19 7.2" /></svg>
);
export const SendIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 2, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}><path d="M21 3 3 10.4l7 2.6 2.6 7L21 3ZM10 13l11-10" /></svg>
);
export const VideoIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 1.9, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}>
    <rect x="3" y="5.5" width="13.5" height="13" rx="3.2" /><path d="M16.5 10.2 21 7.6v8.8l-4.5-2.6" />
  </svg>
);
export const ClockIcon: React.FC<P> = ({ size = 48, color = "currentColor", stroke = 2, style }) => (
  <svg {...base(size, style)} stroke={color} strokeWidth={stroke}><circle cx="12" cy="12" r="8.5" /><path d="M12 7.5V12l3 2" /></svg>
);
export const PersonIcon: React.FC<P> = ({ size = 48, color = "currentColor", style }) => (
  <svg {...base(size, style)} fill={color}><circle cx="12" cy="8.4" r="4" /><path d="M4.5 21c.6-4.2 3.6-6.6 7.5-6.6s6.9 2.4 7.5 6.6Z" /></svg>
);

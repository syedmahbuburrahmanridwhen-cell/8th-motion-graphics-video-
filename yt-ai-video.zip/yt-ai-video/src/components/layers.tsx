import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** Layer 1 — never a flat background: drifting hero/accent glows + faint dot grid */
export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  const d3 = Math.sin(frame / 90 + 1) * 40;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <div style={{ position: "absolute", width: 1500, height: 1500, borderRadius: "50%", top: -760, left: -420 + d1,
        background: `radial-gradient(circle, ${theme.alpha(theme.colors.hero, 0.16)}, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1200, height: 1200, borderRadius: "50%", bottom: -640, right: -360 - d2,
        background: `radial-gradient(circle, ${theme.alpha(theme.colors.accent, 0.09)}, transparent 64%)` }} />
      <div style={{ position: "absolute", width: 900, height: 900, borderRadius: "50%", top: 120 + d3, right: 120,
        background: `radial-gradient(circle, ${theme.alpha(theme.colors.hero, 0.05)}, transparent 66%)` }} />
      <AbsoluteFill style={{
        backgroundImage: `radial-gradient(${theme.alpha(theme.colors.white, 0.07)} 1.5px, transparent 1.5px)`,
        backgroundSize: "64px 64px", backgroundPosition: `${-frame * 0.15}px 0px`,
        maskImage: "radial-gradient(ellipse at center, black 20%, transparent 75%)",
        WebkitMaskImage: "radial-gradient(ellipse at center, black 20%, transparent 75%)",
      }} />
    </AbsoluteFill>
  );
};

/** Layer 4 — colour grade */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.hero, mixBlendMode: "soft-light", opacity: 0.12 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.18), transparent 26%, transparent 74%, rgba(0,0,0,0.24))" }} />
  </AbsoluteFill>
);

/** Layer 5a — procedural grain */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
      backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.06, mixBlendMode: "overlay" }} />
  );
};

/** Layer 5b — vignette (topmost) */
export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 54%, rgba(0,0,0,0.5) 100%)" }} />
);

/** Mask-wipe transition: a hero panel with a dark trailing panel; the scene cut hides behind it. */
export const Wipe: React.FC<{ center: number; dir: 1 | -1; length?: number }> = ({ center, dir, length = 22 }) => {
  const frame = useCurrentFrame();
  const start = center - length / 2;
  if (frame < start - 3 || frame > start + length) return null;
  const W = 1920 * 1.4;
  const travel = W + 1920;
  const p = interpolate(frame, [start, start + length], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const left = -W + p * travel;
  const x = dir === 1 ? left : 1920 - left - W;
  // dark panel leads the red one by 3 frames (same easing) so the red edge is what reveals the next scene
  const trail = interpolate(frame, [start - 3, start + length - 3], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const x2 = dir === 1 ? -W + trail * travel - 180 : 1920 - (-W + trail * travel - 180) - W;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: -40, height: 1160, width: W, left: x2, background: theme.colors.surfaceHi, transform: "skewX(-12deg)" }} />
      <div style={{ position: "absolute", top: -40, height: 1160, width: W, left: x, background: theme.colors.hero, transform: "skewX(-12deg)",
        boxShadow: theme.shadow.heroGlow(0.8) }} />
    </AbsoluteFill>
  );
};

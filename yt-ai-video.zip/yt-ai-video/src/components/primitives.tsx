import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";

export const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** Entrance: opacity + rise + scale (+ optional x), spring driven. */
export const Entrance: React.FC<{
  delay?: number; children: React.ReactNode; style?: React.CSSProperties;
  from?: number; x?: number; scaleFrom?: number; config?: typeof theme.spring.smooth | typeof theme.spring.snappy | typeof theme.spring.bouncy;
}> = ({ delay = 0, children, style, from = 40, x = 0, scaleFrom = 0.94, config = theme.spring.smooth }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config });
  const o = interpolate(p, [0, 0.35], [0, 1], clamp);
  return (
    <div style={{ opacity: o, transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [from, 0])}px) scale(${interpolate(p, [0, 1], [scaleFrom, 1])})`, ...style }}>
      {children}
    </div>
  );
};

/** Quick fade+drop exit for a block, ending at `end` (exits are faster than entrances). */
export const useExit = (start: number, len = 9) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [start, start + len], [0, 1], { ...clamp, easing: theme.ease.in });
  return { p, style: { opacity: 1 - p, transform: `translateY(${-30 * p}px) scale(${1 - 0.03 * p})` } as React.CSSProperties };
};

type WordProps = {
  text: string; size: number; delay?: number; per?: number; weight?: number; color?: string;
  align?: "left" | "center" | "right"; marks?: Record<number, "hero" | "gradient" | "accent">;
  lineHeight?: number; style?: React.CSSProperties; from?: number;
};

/** Word-by-word staggered reveal. Splits on spaces ONLY (never on characters — Bengali conjuncts stay intact). */
export const WordReveal: React.FC<WordProps> = ({
  text, size, delay = 0, per = 4, weight = theme.fonts.heavy, color = theme.colors.text,
  align = "left", marks = {}, lineHeight = 1.32, style, from = 34,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{
      display: "flex", flexWrap: "wrap", columnGap: Math.round(size * 0.27), rowGap: 0,
      justifyContent: align === "center" ? "center" : align === "right" ? "flex-end" : "flex-start",
      fontFamily: theme.fonts.main, fontSize: size, fontWeight: weight, lineHeight, letterSpacing: 0, color, ...style,
    }}>
      {text.split(" ").map((word, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const mark = marks[i];
        const markStyle: React.CSSProperties =
          mark === "hero" ? { color: theme.colors.hero, textShadow: `0 0 ${size * 0.35}px ${theme.glow}` }
          : mark === "accent" ? { color: theme.colors.accent }
          : mark === "gradient" ? { backgroundImage: theme.gradient.hero, WebkitBackgroundClip: "text", backgroundClip: "text", color: "transparent", WebkitTextFillColor: "transparent" }
          : {};
        return (
          <span key={i} style={{
            display: "inline-block", opacity: interpolate(p, [0, 0.4], [0, 1], clamp),
            transform: `translateY(${interpolate(p, [0, 1], [from, 0])}px) scale(${interpolate(p, [0, 1], [0.9, 1])})`,
            ...markStyle,
          }}>{word}</span>
        );
      })}
    </div>
  );
};

/** Line mask reveal: the line rises out of a clipped box. */
export const LineMask: React.FC<{
  children: React.ReactNode; delay?: number; size: number; weight?: number; color?: string;
  align?: "left" | "center"; style?: React.CSSProperties;
}> = ({ children, delay = 0, size, weight = theme.fonts.heavy, color = theme.colors.text, align = "left", style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  return (
    <div style={{ overflow: "hidden", padding: `${size * 0.1}px 0 ${size * 0.3}px`, margin: `${-size * 0.1}px 0 ${-size * 0.3}px`, textAlign: align }}>
      <div style={{
        fontFamily: theme.fonts.main, fontSize: size, fontWeight: weight, lineHeight: 1.3, letterSpacing: 0, color,
        transform: `translateY(${interpolate(p, [0, 1], [110, 0])}%)`, opacity: interpolate(p, [0, 0.25], [0, 1], clamp), ...style,
      }}>{children}</div>
    </div>
  );
};

/** Highlight sweep: a hero bar wipes in behind a word. */
export const SweepWord: React.FC<{
  children: React.ReactNode; delay: number; size: number; textColor?: string; bar?: string; radius?: number; padX?: number;
}> = ({ children, delay, size, textColor = theme.colors.white, bar = theme.colors.hero, radius = 18, padX = 0.28 }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.smooth });
  const sweep = interpolate(p, [0, 1], [0, 1], clamp);
  return (
    <span style={{ position: "relative", display: "inline-block", padding: `0 ${size * padX}px`, fontFamily: theme.fonts.main, fontSize: size, fontWeight: theme.fonts.heavy, lineHeight: 1.3, color: textColor, letterSpacing: 0 }}>
      <span style={{ position: "absolute", left: 0, top: "8%", bottom: "6%", right: 0, borderRadius: radius, background: bar, transformOrigin: "left center", transform: `scaleX(${sweep})`, boxShadow: theme.shadow.heroGlow(0.6) }} />
      <span style={{ position: "relative", opacity: interpolate(p, [0, 0.3], [0, 1], clamp), display: "inline-block", transform: `translateY(${interpolate(p, [0, 1], [18, 0])}px)` }}>{children}</span>
    </span>
  );
};

/** Tap ripple — the "click" visual. Centered on its parent. */
export const Tap: React.FC<{ at: number; size?: number; color?: string }> = ({ at, size = 150, color = theme.colors.accent }) => {
  const frame = useCurrentFrame();
  const t = frame - at;
  if (t < 0 || t > 22) return null;
  const p = interpolate(t, [0, 22], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <div style={{ position: "absolute", left: "50%", top: "50%", width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2, pointerEvents: "none" }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: "50%", border: `3px solid ${color}`, opacity: 1 - p, transform: `scale(${0.35 + p * 0.9})` }} />
      <div style={{ position: "absolute", left: "50%", top: "50%", width: size * 0.2, height: size * 0.2, marginLeft: -size * 0.1, marginTop: -size * 0.1, borderRadius: "50%", background: color, opacity: (1 - p) * 0.8 }} />
    </div>
  );
};

/** Glass card surface */
export const Glass: React.FC<{ children?: React.ReactNode; style?: React.CSSProperties; radius?: number }> = ({ children, style, radius = theme.radius.card }) => (
  <div style={{
    position: "relative", borderRadius: radius, overflow: "hidden",
    background: `linear-gradient(155deg, ${theme.alpha(theme.colors.white, 0.075)}, ${theme.alpha(theme.colors.white, 0.02)} 60%), ${theme.colors.surface}`,
    boxShadow: theme.shadow.card, ...style,
  }}>
    <div style={{ position: "absolute", inset: 0, borderRadius: radius, boxShadow: `inset 0 1px 0 ${theme.alpha(theme.colors.white, 0.12)}`, pointerEvents: "none" }} />
    {children}
  </div>
);

/** Idle breathing helper */
export const useBreathe = (amp = 0.012, period = 24, phase = 0) => {
  const frame = useCurrentFrame();
  return 1 + Math.sin(frame / period + phase) * amp;
};
export const useFloat = (amp = 6, period = 32, phase = 0) => {
  const frame = useCurrentFrame();
  return Math.sin(frame / period + phase) * amp;
};

export const Txt: React.FC<{ size: number; weight?: number; color?: string; style?: React.CSSProperties; children: React.ReactNode }> = ({ size, weight = theme.fonts.mid, color = theme.colors.text, style, children }) => (
  <div style={{ fontFamily: theme.fonts.main, fontSize: size, fontWeight: weight, color, lineHeight: 1.3, letterSpacing: 0, ...style }}>{children}</div>
);

import React from "react";
import { theme } from "../theme";

/** Glossy phone frame. Screen content goes in children (absolute-positioned area). */
export const Phone: React.FC<{ w: number; children?: React.ReactNode; style?: React.CSSProperties; shine?: number }> = ({ w, children, style, shine = 0 }) => {
  const h = Math.round(w * 2.04);
  const bez = w * 0.032;
  return (
    <div style={{ position: "relative", width: w, height: h, borderRadius: w * 0.17, background: "#040405", boxShadow: `${theme.shadow.card}, inset 0 0 0 2px ${theme.alpha(theme.colors.white, 0.14)}`, ...style }}>
      <div style={{ position: "absolute", left: bez, top: bez, right: bez, bottom: bez, borderRadius: w * 0.14, overflow: "hidden", background: theme.colors.bg }}>
        {children}
        <div style={{ position: "absolute", top: w * 0.028, left: "50%", width: w * 0.27, height: w * 0.07, marginLeft: -w * 0.135, borderRadius: 99, background: "#000" }} />
      </div>
      <div style={{ position: "absolute", inset: 0, borderRadius: w * 0.17, pointerEvents: "none",
        background: `linear-gradient(${115 + shine}deg, ${theme.alpha(theme.colors.white, 0.13)} 0%, transparent 34%, transparent 70%, ${theme.alpha(theme.colors.white, 0.05)} 100%)` }} />
    </div>
  );
};

/** Glossy browser window. */
export const Browser: React.FC<{ w: number; h: number; children?: React.ReactNode; style?: React.CSSProperties }> = ({ w, h, children, style }) => (
  <div style={{ position: "relative", width: w, height: h, borderRadius: 34, overflow: "hidden", background: theme.colors.bgAlt, boxShadow: theme.shadow.card, ...style }}>
    <div style={{ height: 70, display: "flex", alignItems: "center", padding: "0 28px", columnGap: 12, background: theme.colors.surface, borderBottom: `1px solid ${theme.line}` }}>
      {[0, 1, 2].map((i) => <div key={i} style={{ width: 15, height: 15, borderRadius: 99, background: theme.colors.surfaceHi }} />)}
      <div style={{ marginLeft: 26, height: 34, width: w * 0.46, borderRadius: 17, background: theme.colors.bg }} />
    </div>
    <div style={{ position: "absolute", left: 0, right: 0, top: 70, bottom: 0 }}>{children}</div>
    <div style={{ position: "absolute", inset: 0, pointerEvents: "none", background: `linear-gradient(118deg, ${theme.alpha(theme.colors.white, 0.08)} 0%, transparent 32%)` }} />
  </div>
);

export const Bar: React.FC<{ w: number | string; h: number; color?: string; style?: React.CSSProperties }> = ({ w, h, color = theme.colors.surfaceHi, style }) => (
  <div style={{ width: w, height: h, borderRadius: h / 2, background: color, ...style }} />
);

import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at, cueStart, LEAD, scene } from "../timing";
import { clamp, Entrance, Txt, useFloat } from "../components/primitives";
import { CheckIcon, ImageIcon, MusicIcon, PlayIcon, SparkleIcon, VideoIcon } from "../components/icons";
import type { SfxEvent } from "../sfxTypes";

const S = scene("carousel").from;
const tIn = 6;
const ROT = 22; // frames per rotation
const r1 = at(7, 0.28) - LEAD - 11 - S; // rotate to "Photo to video"
const r2 = at(8, 0.22) - LEAD - 10 - S; // rotate to "Music"
const tBanner = cueStart(9) - LEAD - S;

export const carouselSfx: SfxEvent[] = [
  { frame: S + tIn + 8, name: "pop", volume: 0.27 },
  { frame: S + r1 + 6, name: "pop", volume: 0.29, rate: 1.05 },
  { frame: S + r2 + 6, name: "pop", volume: 0.3, rate: 1.1 },
  { frame: S + tBanner + 6, name: "click", volume: 0.3 },
];

const items = [
  { key: "video", label: ["Video"], Icon: VideoIcon },
  { key: "photo", label: ["Photo to", "video"], Icon: ImageIcon },
  { key: "music", label: ["Music"], Icon: MusicIcon },
] as const;

const progressAt = (frame: number) =>
  interpolate(frame, [r1, r1 + ROT, r2, r2 + ROT], [0, 1, 1, 2], { ...clamp, easing: theme.ease.inOut });

const Illustration: React.FC<{ k: string; frame: number }> = ({ k, frame }) => {
  if (k === "music") {
    return (
      <div style={{ display: "flex", alignItems: "flex-end", columnGap: 14, height: 120 }}>
        {[0, 1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} style={{ width: 20, borderRadius: 10, background: theme.colors.accent, height: 28 + (Math.sin(frame / 5 + i * 1.3) * 0.5 + 0.5) * 84 }} />
        ))}
      </div>
    );
  }
  if (k === "photo") {
    return (
      <div style={{ display: "flex", alignItems: "center", columnGap: 22 }}>
        <div style={{ width: 120, height: 96, borderRadius: 20, background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center" }}><ImageIcon size={52} color={theme.colors.textDim} /></div>
        <SparkleIcon size={40} color={theme.colors.accent} style={{ transform: `rotate(${frame * 1.4}deg)` }} />
        <div style={{ width: 120, height: 96, borderRadius: 20, background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center" }}><PlayIcon size={46} color={theme.colors.text} /></div>
      </div>
    );
  }
  const w = interpolate(frame % 120, [0, 120], [8, 100], { easing: theme.ease.inOut });
  return (
    <div style={{ width: 300, height: 120, borderRadius: 22, background: theme.colors.surfaceHi, position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", left: "50%", top: "46%", marginLeft: -26, marginTop: -26 }}><PlayIcon size={52} color={theme.colors.text} /></div>
      <div style={{ position: "absolute", left: 18, right: 18, bottom: 14, height: 8, borderRadius: 4, background: theme.alpha(theme.colors.white, 0.14) }}>
        <div style={{ width: `${w}%`, height: "100%", borderRadius: 4, background: theme.colors.accent }} />
      </div>
    </div>
  );
};

export const CarouselScene: React.FC = () => {
  const frame = useCurrentFrame();
  const P = progressAt(frame) + interpolate(frame, [tBanner, tBanner + 60], [0, 0.0], clamp);
  const bannerP = interpolate(frame, [tBanner, tBanner + 16], [0, 1], { ...clamp, easing: theme.ease.out });
  const fl = useFloat(7, 34);
  const idx = Math.round(P);
  const frac = P - idx;

  return (
    <AbsoluteFill>
      {/* counter */}
      <div style={{ position: "absolute", left: 140, top: 96 }}>
        <Entrance delay={tIn} from={20} config={theme.spring.snappy}>
          <div style={{ display: "flex", alignItems: "baseline", columnGap: 18, fontFamily: theme.fonts.main, fontWeight: theme.fonts.heavy, lineHeight: 1.2 }}>
            <div style={{ height: 96, overflow: "hidden", position: "relative", width: 110 }}>
              <div style={{ fontSize: 88, color: theme.colors.text, transform: `translateY(${-frac * 40}px)`, opacity: 1 - Math.abs(frac) * 1.2 }}>{String(idx + 1).padStart(2, "0")}</div>
            </div>
            <div style={{ fontSize: 52, color: theme.colors.textFaint }}>/ 03</div>
          </div>
        </Entrance>
      </div>

      {/* 3D carousel */}
      <div style={{ position: "absolute", inset: 0, perspective: 2000, perspectiveOrigin: "50% 45%" }}>
        {items.map((it, i) => {
          let d = i - P;
          if (d > 1.5) d -= 3;
          if (d < -1.5) d += 3;
          const ad = Math.abs(d);
          const active = Math.max(0, 1 - ad * 1.6) * (1 - bannerP * 0.9);
          const o = interpolate(ad, [0, 1, 1.45], [1, 0.5, 0], clamp);
          const enter = interpolate(frame - tIn - i * 5, [0, 26], [0, 1], { ...clamp, easing: theme.ease.out });
          return (
            <div key={it.key} style={{
              position: "absolute", left: 960 - 290, top: 210 + fl, width: 580, height: 640, zIndex: Math.round(10 - ad * 5),
              opacity: o * enter,
              transform: `translateX(${d * 640}px) translateZ(${-ad * 300}px) rotateY(${-d * 34}deg) translateY(${(1 - enter) * 90}px)`,
              filter: `brightness(${1 - Math.min(1, ad) * 0.35})`,
            }}>
              <div style={{ position: "relative", width: "100%", height: "100%", borderRadius: theme.radius.card + 8, overflow: "hidden",
                background: `linear-gradient(155deg, ${theme.alpha(theme.colors.white, 0.08)}, ${theme.alpha(theme.colors.white, 0.015)} 60%), ${theme.colors.surface}`, boxShadow: theme.shadow.card }}>
                <div style={{ position: "absolute", inset: 0, boxShadow: `inset 0 1px 0 ${theme.alpha(theme.colors.white, 0.14)}`, borderRadius: theme.radius.card + 8 }} />
                <div style={{ position: "absolute", left: 44, top: 44, width: 150, height: 150, borderRadius: 42, background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <div style={{ position: "absolute", inset: 0, borderRadius: 42, background: theme.colors.hero, opacity: active, boxShadow: `0 0 ${60 * active}px ${theme.alpha(theme.colors.hero, 0.45)}` }} />
                  <it.Icon size={84} color={theme.colors.text} style={{ position: "relative" }} />
                </div>
                <div style={{ position: "absolute", right: 44, top: 60, fontFamily: theme.fonts.main, fontWeight: theme.fonts.heavy, fontSize: 52, color: theme.colors.textFaint }}>0{i + 1}</div>
                <div style={{ position: "absolute", left: 44, right: 44, top: 250, display: "flex", justifyContent: "center" }}>
                  <Illustration k={it.key} frame={frame} />
                </div>
                <div style={{ position: "absolute", left: 44, right: 44, bottom: 40 }}>
                  {it.label.map((l, j) => (
                    <Txt key={j} size={92} weight={theme.fonts.heavy} style={{ lineHeight: 1.18 }}>{l}</Txt>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* dots */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 912, display: "flex", justifyContent: "center", columnGap: 14, opacity: 1 - bannerP }}>
        {items.map((_, i) => (
          <div key={i} style={{ height: 12, width: 12 + Math.max(0, 1 - Math.abs(i - P)) * 44, borderRadius: 6, background: theme.alpha(theme.colors.white, 0.18 + Math.max(0, 1 - Math.abs(i - P)) * 0.6) }} />
        ))}
      </div>

      {/* no-hassle banner */}
      <div style={{ position: "absolute", left: 0, right: 0, top: 888, display: "flex", justifyContent: "center", opacity: bannerP, transform: `translateY(${(1 - bannerP) * 50}px) scale(${0.92 + bannerP * 0.08})` }}>
        <div style={{ display: "flex", alignItems: "center", columnGap: 26, padding: "8px 56px 8px 14px", borderRadius: 99, background: theme.colors.surfaceHi, boxShadow: theme.shadow.soft }}>
          <div style={{ width: 84, height: 84, borderRadius: 42, background: theme.colors.hero, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.heroGlow(0.6) }}>
            <CheckIcon size={48} color={theme.colors.white} />
          </div>
          <Txt size={80} weight={theme.fonts.heavy}>ঝামেলা ছাড়াই</Txt>
        </div>
      </div>
    </AbsoluteFill>
  );
};

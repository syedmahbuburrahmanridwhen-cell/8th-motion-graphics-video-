import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at, cueStart, LEAD, scene } from "../timing";
import { clamp, Entrance, SweepWord, Txt, WordReveal, useFloat } from "../components/primitives";
import { PlayIcon, PlusIcon, SparkleIcon } from "../components/icons";
import { Phone } from "../components/devices";
import type { SfxEvent } from "../sfxTypes";

const S = scene("phone").from;
const tPhone = cueStart(4) - LEAD - S;
const tChip = at(4, 0.3) - LEAD - S;
const tL1 = at(4, 0.6) - LEAD - S;
const tFree = at(5, 0.3) - LEAD - S;
const tL3 = cueStart(6) - LEAD - S;
const tGen = cueStart(6) - S;

export const phoneSfx: SfxEvent[] = [
  { frame: S + tPhone + 10, name: "pop", volume: 0.26 },
  { frame: S + tFree + 8, name: "pop", volume: 0.3, rate: 1.04 },
  { frame: S + tGen, name: "pop", volume: 0.27, rate: 0.96 },
];

const Dim: React.FC<{ from: number; children: React.ReactNode }> = ({ from, children }) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [from, from + 12], [1, 0.42], { ...clamp, easing: theme.ease.out });
  return <div style={{ opacity: o }}>{children}</div>;
};

const PhoneScreen: React.FC = () => {
  const frame = useCurrentFrame();
  const gen = interpolate(frame, [tGen, tGen + 14], [0, 1], { ...clamp, easing: theme.ease.out });
  const prog = interpolate(frame, [tGen + 6, tGen + 70], [0, 1], { ...clamp, easing: theme.ease.inOut });
  const ring = interpolate(frame, [tGen, tGen + 22], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 28, right: 28, top: 70, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Txt size={40} weight={theme.fonts.heavy}>YouTube</Txt>
        <div style={{ display: "flex", columnGap: 14 }}>
          <div style={{ width: 40, height: 40, borderRadius: 20, background: theme.colors.surfaceHi }} />
          <div style={{ width: 40, height: 40, borderRadius: 20, background: theme.colors.surfaceHi }} />
        </div>
      </div>
      <div style={{ position: "absolute", left: 20, right: 20, top: 140, bottom: 160, borderRadius: 34, overflow: "hidden", background: `linear-gradient(165deg, ${theme.colors.surfaceHi}, ${theme.colors.surface})` }}>
        <div style={{ position: "absolute", inset: 0, opacity: gen, background: `linear-gradient(160deg, ${theme.alpha(theme.colors.accent, 0.38)}, ${theme.colors.surfaceHi} 52%, ${theme.colors.bgAlt})` }} />
        <div style={{ position: "absolute", left: "50%", top: "44%", width: 128, height: 128, marginLeft: -64, marginTop: -64, borderRadius: "50%", background: theme.alpha(theme.colors.white, 0.14), display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${0.9 + gen * 0.1})` }}>
          <PlayIcon size={62} color={theme.colors.text} style={{ marginLeft: 6 }} />
        </div>
        <div style={{ position: "absolute", left: "50%", top: "44%", width: 128, height: 128, marginLeft: -64, marginTop: -64, borderRadius: "50%", border: `3px solid ${theme.colors.accent}`, opacity: (1 - ring) * gen, transform: `scale(${1 + ring * 1.4})` }} />
        <div style={{ position: "absolute", left: 22, top: 22, opacity: gen, transform: `scale(${0.4 + gen * 0.6}) rotate(${frame * 1.2}deg)` }}><SparkleIcon size={52} color={theme.colors.accent} /></div>
        <div style={{ position: "absolute", right: 16, bottom: 90, display: "flex", flexDirection: "column", rowGap: 16 }}>
          {[0, 1, 2].map((i) => <div key={i} style={{ width: 50, height: 50, borderRadius: 25, background: theme.alpha(theme.colors.white, 0.14) }} />)}
        </div>
        <div style={{ position: "absolute", left: 26, bottom: 36, width: 160, height: 18, borderRadius: 9, background: theme.alpha(theme.colors.white, 0.16) }} />
        <div style={{ position: "absolute", left: 26, right: 26, bottom: 0, height: 8, background: theme.alpha(theme.colors.white, 0.12) }}>
          <div style={{ width: `${prog * 100}%`, height: "100%", background: theme.colors.accent }} />
        </div>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 140, display: "flex", alignItems: "center", justifyContent: "space-around", padding: "0 18px", borderTop: `1px solid ${theme.line}`, background: theme.colors.bg }}>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: theme.colors.textFaint }} />
        <div style={{ width: 44, height: 44, borderRadius: 12, background: theme.colors.textFaint }} />
        <div style={{ width: 78, height: 78, borderRadius: 39, border: `3px solid ${theme.colors.text}`, display: "flex", alignItems: "center", justifyContent: "center" }}><PlusIcon size={40} color={theme.colors.text} /></div>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: theme.colors.textFaint }} />
        <div style={{ width: 44, height: 44, borderRadius: 12, background: theme.colors.textFaint }} />
      </div>
    </AbsoluteFill>
  );
};

export const PhoneScene: React.FC = () => {
  const frame = useCurrentFrame();
  const fl = useFloat(9, 36);
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 40, top: 100, width: 860, height: 860, background: `radial-gradient(circle, ${theme.alpha(theme.colors.accent, 0.12)}, transparent 62%)` }} />
      <div style={{ position: "absolute", left: 260, top: 118 }}>
        <Entrance delay={tPhone} from={170} scaleFrom={0.92} config={theme.spring.bouncy}>
          <div style={{ transform: `perspective(1800px) rotateY(11deg) rotateX(3deg) translateY(${fl}px)` }}>
            <Phone w={420} shine={Math.sin(frame / 60) * 14}><PhoneScreen /></Phone>
          </div>
        </Entrance>
      </div>

      <div style={{ position: "absolute", left: 930, right: 100, top: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center", rowGap: 18 }}>
        <Entrance delay={tChip} from={22} config={theme.spring.snappy} style={{ alignSelf: "flex-start" }}>
          <div style={{ padding: "4px 34px", borderRadius: 99, border: `2px solid ${theme.line}`, background: theme.colors.surface }}>
            <Txt size={54} weight={theme.fonts.mid} color={theme.colors.textDim}>সরাসরি</Txt>
          </div>
        </Entrance>
        <Dim from={tFree}>
          <WordReveal text="ফোনের" size={104} delay={tL1} per={4} />
          <WordReveal text="YouTube app" size={104} delay={tL1 + 4} per={4} />
        </Dim>
        <Dim from={tL3}>
          <div style={{ display: "flex", alignItems: "center", columnGap: 40 }}>
            <Entrance delay={tFree} from={30} config={theme.spring.snappy}><Txt size={128} weight={theme.fonts.heavy}>একদম</Txt></Entrance>
            <SweepWord delay={tFree + 6} size={150}>free</SweepWord>
          </div>
        </Dim>
        <div>
          <WordReveal text="চমৎকার ভিডিও" size={86} delay={tL3} per={4} color={theme.colors.accent} />
          <WordReveal text="বানিয়ে নিন" size={86} delay={tL3 + 5} per={4} color={theme.colors.accent} />
        </div>
      </div>
    </AbsoluteFill>
  );
};

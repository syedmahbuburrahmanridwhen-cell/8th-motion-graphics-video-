import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at, cueStart, LEAD, scene } from "../timing";
import { clamp, Entrance, Txt, WordReveal, useExit, useFloat } from "../components/primitives";
import { SparkleIcon } from "../components/icons";
import { Bar, Browser, Phone } from "../components/devices";
import type { SfxEvent } from "../sfxTypes";

const S = scene("premium").from;
const tPill1 = at(19, 0.05) - LEAD - S;
const tPill2 = at(19, 0.55) - LEAD - S;
const tBrowser = 12;
const tPhone = 20;
const tHead = cueStart(20) - LEAD - S;
const tPolish = cueStart(20) - S;

export const premiumSfx: SfxEvent[] = [
  { frame: S + tPill1 + 3, name: "pop", volume: 0.26 },
  { frame: S + tPill2 + 3, name: "pop", volume: 0.27, rate: 1.07 },
  { frame: S + tBrowser + 6, name: "pop", volume: 0.25, rate: 0.96 },
  { frame: S + tHead + 1, name: "whoosh_soft", volume: 0.2, rate: 0.96 },
  { frame: S + tPolish + 2, name: "chime", volume: 0.26 },
];

const Pill: React.FC<{ t: number; children: React.ReactNode }> = ({ t, children }) => (
  <Entrance delay={t} from={30} scaleFrom={0.86} config={theme.spring.bouncy}>
    <div style={{ padding: "4px 44px", borderRadius: 99, background: theme.colors.surfaceHi, boxShadow: theme.shadow.soft }}>
      <Txt size={70} weight={theme.fonts.heavy}>{children}</Txt>
    </div>
  </Entrance>
);

const BrowserContent: React.FC<{ polish: number }> = ({ polish }) => {
  const sk = (a: number) => theme.alpha(theme.colors.white, a);
  return (
    <div style={{ padding: "30px 44px", display: "flex", flexDirection: "column", rowGap: 26 }}>
      <div style={{ display: "flex", alignItems: "center", columnGap: 18 }}>
        <div style={{ width: 46, height: 46, borderRadius: 23, background: polish > 0.5 ? theme.colors.accent : theme.colors.surfaceHi }} />
        <div style={{ flex: 1 }} />
        {[0, 1, 2, 3].map((i) => <Bar key={i} w={80} h={14} color={sk(0.1 + polish * 0.12)} />)}
      </div>
      <div style={{ display: "flex", columnGap: 44, alignItems: "stretch" }}>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", rowGap: 18, paddingTop: 6 }}>
          <Bar w="88%" h={40} color={polish > 0.1 ? theme.alpha(theme.colors.text, 0.92) : theme.colors.surfaceHi} />
          <Bar w="62%" h={40} color={polish > 0.1 ? theme.alpha(theme.colors.text, 0.92) : theme.colors.surfaceHi} />
          <Bar w="80%" h={16} color={sk(0.1 + polish * 0.12)} style={{ marginTop: 10 }} />
          <Bar w="66%" h={16} color={sk(0.1 + polish * 0.12)} />
          <div style={{ marginTop: 18, width: 230, height: 66, borderRadius: 33, background: theme.colors.hero, opacity: polish, transform: `scale(${0.8 + polish * 0.2})`, transformOrigin: "left center", boxShadow: theme.shadow.heroGlow(0.5) }} />
        </div>
        <div style={{ width: 340, height: 290, borderRadius: 30, position: "relative", overflow: "hidden", background: `linear-gradient(150deg, ${theme.alpha(theme.colors.accent, 0.1 + polish * 0.3)}, ${theme.colors.surfaceHi})` }}>
          <div style={{ position: "absolute", right: 24, top: 22, opacity: polish }}><SparkleIcon size={54} color={theme.colors.accent} /></div>
        </div>
      </div>
      <div style={{ display: "flex", columnGap: 26 }}>
        {[0, 1, 2].map((i) => <div key={i} style={{ flex: 1, height: 104, borderRadius: 24, background: sk(0.06 + polish * 0.05) }} />)}
      </div>
    </div>
  );
};

const PhoneContent: React.FC<{ polish: number }> = ({ polish }) => (
  <div style={{ position: "absolute", inset: 0, padding: "66px 20px 20px", display: "flex", flexDirection: "column", rowGap: 18 }}>
    <Bar w="46%" h={18} color={theme.alpha(theme.colors.white, 0.16)} />
    <div style={{ height: 210, borderRadius: 24, position: "relative", background: `linear-gradient(155deg, ${theme.alpha(theme.colors.accent, 0.1 + polish * 0.34)}, ${theme.colors.surfaceHi})` }}>
      <div style={{ position: "absolute", left: 18, top: 16, opacity: polish }}><SparkleIcon size={38} color={theme.colors.accent} /></div>
    </div>
    <Bar w="86%" h={16} /><Bar w="62%" h={16} />
    <div style={{ marginTop: 8, height: 62, borderRadius: 31, background: theme.alpha(theme.colors.white, 0.1 + polish * 0.82) }} />
  </div>
);

export const PremiumScene: React.FC = () => {
  const frame = useCurrentFrame();
  const flB = useFloat(7, 34);
  const flP = useFloat(8, 30, 1.6);
  const polish = interpolate(frame, [tPolish, tPolish + 22], [0, 1], { ...clamp, easing: theme.ease.out });
  const shine = interpolate(frame, [tPolish + 4, tPolish + 34], [-40, 140], { ...clamp, easing: theme.ease.inOut });
  const ex = useExit(tHead - 10, 9);
  const badge = interpolate(frame, [tPolish + 8, tPolish + 24], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <AbsoluteFill>
      {/* kicker row (cue 19) */}
      <div style={{ position: "absolute", top: 120, left: 0, right: 0, display: "flex", justifyContent: "center", alignItems: "center", columnGap: 34, ...ex.style }}>
        <Pill t={tPill1}>personal business</Pill>
        <Entrance delay={tPill1 + 8} from={20} config={theme.spring.snappy}><Txt size={62} weight={theme.fonts.mid} color={theme.colors.textDim}>বা</Txt></Entrance>
        <Pill t={tPill2}>brand</Pill>
        <Entrance delay={tPill2 + 6} from={20} config={theme.spring.snappy}><Txt size={62} weight={theme.fonts.mid} color={theme.colors.textDim}>জন্য</Txt></Entrance>
      </div>
      {/* headline (cue 20) */}
      <div style={{ position: "absolute", top: 96, left: 0, right: 0 }}>
        <WordReveal text="premium website বা app" size={120} delay={tHead} per={4} align="center" marks={{ 0: "accent" }} />
      </div>

      {/* devices */}
      <div style={{ position: "absolute", left: 400, top: 350 + flB }}>
        <Entrance delay={tBrowser} from={120} scaleFrom={0.92} config={theme.spring.bouncy}>
          <div style={{ position: "relative" }}>
            <Browser w={1020} h={650}><BrowserContent polish={polish} /></Browser>
            <div style={{ position: "absolute", inset: 0, borderRadius: 34, overflow: "hidden", pointerEvents: "none" }}>
              <div style={{ position: "absolute", top: -40, bottom: -40, width: 200, left: `${shine}%`, transform: "skewX(-18deg)", background: `linear-gradient(90deg, transparent, ${theme.alpha(theme.colors.white, 0.16)}, transparent)` }} />
            </div>
            <div style={{ position: "absolute", right: 200, top: 10, display: "flex", alignItems: "center", columnGap: 12, padding: "4px 26px 4px 16px", borderRadius: 99, border: `2px solid ${theme.colors.accent}`, background: theme.alpha(theme.colors.bg, 0.7), opacity: badge, transform: `translateY(${(1 - badge) * -16}px)` }}>
              <SparkleIcon size={34} color={theme.colors.accent} />
              <Txt size={40} weight={theme.fonts.heavy} color={theme.colors.accent}>premium</Txt>
            </div>
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 1310, top: 420 + flP }}>
        <Entrance delay={tPhone} from={150} scaleFrom={0.92} config={theme.spring.bouncy}>
          <Phone w={290} shine={8}><PhoneContent polish={polish} /></Phone>
        </Entrance>
      </div>
    </AbsoluteFill>
  );
};

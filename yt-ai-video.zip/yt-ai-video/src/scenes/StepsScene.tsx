import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at, cueStart, LEAD, scene } from "../timing";
import { clamp, Entrance, Tap, Txt, useBreathe } from "../components/primitives";
import { ImageIcon, MusicIcon, PlusIcon, SparkleIcon, VideoIcon } from "../components/icons";
import type { SfxEvent } from "../sfxTypes";

const S = scene("steps").from;
const s1 = cueStart(10) - LEAD - S;
const s2 = cueStart(11) - LEAD - S;
const s3 = at(11, 0.78) - LEAD - S;
const TAP = 15;
const o1 = at(12, 0.45) - LEAD - S; // video
const o2 = at(12, 0.78) - LEAD - S; // photo to video
const o3 = at(13, 0.4) - LEAD - S; // music
const tBranch = s3 + TAP + 4;

export const stepsSfx: SfxEvent[] = [
  { frame: S + s1 + 4, name: "pop", volume: 0.26 },
  { frame: S + s1 + TAP, name: "click", volume: 0.3 },
  { frame: S + s2 + 4, name: "pop", volume: 0.26, rate: 1.04 },
  { frame: S + s2 + TAP, name: "click", volume: 0.28, rate: 0.96 },
  { frame: S + s3 + 4, name: "pop", volume: 0.27, rate: 1.08 },
  { frame: S + s3 + TAP, name: "click", volume: 0.3, rate: 1.04 },
  { frame: S + o1 + 5, name: "pop", volume: 0.28 },
  { frame: S + o2 + 5, name: "pop", volume: 0.27, rate: 1.05 },
  { frame: S + o3 + 5, name: "pop", volume: 0.29, rate: 1.1 },
];

const X = [400, 960, 1520];
const NODE_Y = 285;
const TILE = 230;

const Tile: React.FC<{ n: number; x: number; at: number; nextAt?: number; label: string; children: React.ReactNode }> = ({ n, x, at: t, nextAt, label, children }) => {
  const frame = useCurrentFrame();
  const br = useBreathe(0.012, 26, n);
  // hero fill is held only by the most recent step
  const active = interpolate(frame, [t + TAP - 4, t + TAP + 6], [0, 1], clamp) * (nextAt ? interpolate(frame, [nextAt, nextAt + 10], [1, 0], clamp) : 1);
  return (
    <div style={{ position: "absolute", left: x - TILE / 2, top: NODE_Y - TILE / 2, width: TILE }}>
      <Entrance delay={t} from={70} scaleFrom={0.86} config={theme.spring.bouncy}>
        <div style={{ transform: `scale(${br})` }}>
          <div style={{ position: "relative", width: TILE, height: TILE, borderRadius: 58, background: theme.colors.surface, boxShadow: theme.shadow.card, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ position: "absolute", inset: 0, borderRadius: 58, background: theme.colors.hero, opacity: active, boxShadow: theme.shadow.heroGlow(0.7) }} />
            <div style={{ position: "relative" }}>{children}</div>
            <div style={{ position: "absolute", left: 18, top: 12, fontFamily: theme.fonts.main, fontWeight: theme.fonts.heavy, fontSize: 40, color: theme.colors.textDim, opacity: 1 - active * 0.4 }}>0{n}</div>
            <Tap at={t + TAP} size={260} />
          </div>
          <div style={{ marginTop: 22, textAlign: "center" }}><Txt size={64} weight={theme.fonts.heavy} style={{ whiteSpace: "nowrap" }}>{label}</Txt></div>
        </div>
      </Entrance>
    </div>
  );
};

const Connector: React.FC<{ x1: number; x2: number; start: number }> = ({ x1, x2, start }) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [start, start + 18], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <div style={{ position: "absolute", left: x1, top: NODE_Y - 3, width: x2 - x1, height: 6 }}>
      <div style={{ position: "absolute", inset: 0, borderRadius: 3, background: theme.alpha(theme.colors.white, 0.08) }} />
      <div style={{ position: "absolute", left: 0, top: 0, height: 6, width: `${p * 100}%`, borderRadius: 3, background: theme.colors.accent }} />
      <div style={{ position: "absolute", left: `${p * 100}%`, top: -9, width: 24, height: 24, marginLeft: -22, borderTop: `6px solid ${theme.colors.accent}`, borderRight: `6px solid ${theme.colors.accent}`, transform: "rotate(45deg)", opacity: p > 0.02 ? 1 : 0, borderRadius: 3 }} />
    </div>
  );
};

const OptionChip: React.FC<{ x: number; at: number; label: string; Icon: React.FC<{ size?: number; color?: string }> }> = ({ x, at: t, label, Icon }) => (
  <div style={{ position: "absolute", left: x, top: 740, transform: "translateX(-50%)", whiteSpace: "nowrap" }}>
    <Entrance delay={t} from={50} scaleFrom={0.9} config={theme.spring.bouncy}>
      <div style={{ display: "flex", alignItems: "center", columnGap: 26, padding: "16px 40px 16px 18px", borderRadius: 99, background: theme.colors.surface, boxShadow: theme.shadow.card }}>
        <div style={{ width: 100, height: 100, borderRadius: 50, background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon size={54} color={theme.colors.accent} /></div>
        <Txt size={54} weight={theme.fonts.heavy} style={{ whiteSpace: "nowrap" }}>{label}</Txt>
      </div>
    </Entrance>
  </div>
);

export const StepsScene: React.FC = () => {
  const frame = useCurrentFrame();
  const draw = (start: number, len: number) => interpolate(frame, [start, start + len], [0, 1], { ...clamp, easing: theme.ease.inOut });
  const v1 = draw(tBranch, 12); // down from node 3
  const h = draw(tBranch + 10, 20); // bar leftwards
  const drops = draw(tBranch + 26, 12);
  const LBL_BOTTOM = NODE_Y + TILE / 2 + 22 + 84;
  const BAR_Y = 640;
  return (
    <AbsoluteFill>
      <Connector x1={X[0] + TILE / 2 + 24} x2={X[1] - TILE / 2 - 24} start={s2 - 2} />
      <Connector x1={X[1] + TILE / 2 + 24} x2={X[2] - TILE / 2 - 24} start={s3 - 2} />

      <Tile n={1} x={X[0]} at={s1} nextAt={s2 + TAP - 4} label="plus icon"><PlusIcon size={112} color={theme.colors.text} stroke={2.4} /></Tile>
      <Tile n={2} x={X[1]} at={s2} nextAt={s3 + TAP - 4} label="Shorts">
        <div style={{ width: 84, height: 132, borderRadius: 22, border: `5px solid ${theme.colors.text}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ width: 0, height: 0, borderTop: "16px solid transparent", borderBottom: "16px solid transparent", borderLeft: `26px solid ${theme.colors.text}`, marginLeft: 6 }} />
        </div>
      </Tile>
      <Tile n={3} x={X[2]} at={s3} label="star icon"><SparkleIcon size={116} color={theme.colors.white} /></Tile>

      {/* branch from step 3 to the three options */}
      <div style={{ display: v1 > 0 ? "block" : "none", position: "absolute", left: X[2] - 3, top: LBL_BOTTOM, width: 6, height: (BAR_Y - LBL_BOTTOM) * v1, background: theme.colors.accent, borderRadius: 3 }} />
      <div style={{ display: h > 0 ? "block" : "none", position: "absolute", left: X[2] - (X[2] - X[0]) * h - 3, top: BAR_Y - 3, width: (X[2] - X[0]) * h + 6, height: 6, background: theme.colors.accent, borderRadius: 3 }} />
      {X.map((x, i) => (
        <div key={i} style={{ position: "absolute", left: x - 3, top: BAR_Y, width: 6, height: (740 - BAR_Y - 8) * drops, background: theme.colors.accent, borderRadius: 3 }} />
      ))}

      <OptionChip x={X[0]} at={o1} label="video" Icon={VideoIcon} />
      <OptionChip x={X[1]} at={o2} label="photo to video" Icon={ImageIcon} />
      <OptionChip x={X[2]} at={o3} label="music" Icon={MusicIcon} />
    </AbsoluteFill>
  );
};

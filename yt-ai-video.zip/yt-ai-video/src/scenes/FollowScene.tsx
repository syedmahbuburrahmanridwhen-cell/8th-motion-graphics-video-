import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at, cueStart, LEAD, scene } from "../timing";
import { clamp, Entrance, Glass, SweepWord, Tap, Txt, WordReveal, useBreathe, useExit, useFloat } from "../components/primitives";
import { CheckIcon, PersonIcon, PlusIcon, SendIcon } from "../components/icons";
import type { SfxEvent } from "../sfxTypes";

const S = scene("follow").from;
const pIn = cueStart(15) - LEAD - S;
const h1 = at(15, 0.15) - LEAD - S;
const tChan = at(15, 0.7) - LEAD - S;
const tPage = at(16, 0.1) - LEAD - S;
const tFollowLine = at(16, 0.2) - LEAD - S;
const tFollow = at(16, 0.45) - S; // tap
const p2 = cueStart(17) - LEAD - S; // phase 2 in
const tBub = at(17, 0.3) - LEAD - S;
const tShareLine = cueStart(18) - LEAD - S;
const tSend = at(18, 0.12) - S; // send tap

export const followSfx: SfxEvent[] = [
  { frame: S + pIn + 4, name: "chime", volume: 0.26 },
  { frame: S + tFollow - 2, name: "click", volume: 0.32 },
  { frame: S + tBub, name: "pop", volume: 0.26 },
  { frame: S + tShareLine + 8, name: "pop", volume: 0.28, rate: 1.05 },
  { frame: S + tSend - 1, name: "click", volume: 0.3, rate: 1.04 },
  { frame: S + tSend + 18, name: "pop", volume: 0.24, rate: 1.1 },
];

const ProfileCard: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = { durationInFrames: scene("follow").duration };
  const kb = interpolate(frame, [0, durationInFrames], [1, 1.08], { easing: theme.ease.inOut, ...clamp });
  const fl = useFloat(6, 34);
  const press = interpolate(frame, [tFollow - 2, tFollow + 2, tFollow + 8], [1, 0.94, 1], { ...clamp, easing: theme.ease.out });
  const swap = interpolate(frame, [tFollow + 2, tFollow + 9], [0, 1], clamp);
  return (
    <div style={{ position: "absolute", left: 130, top: 150 }}>
      <Entrance delay={pIn} from={80} scaleFrom={0.92} config={theme.spring.smooth}>
        <div style={{ transform: `translateY(${fl}px)` }}>
          <Glass style={{ width: 680, height: 780 }}>
            <div style={{ position: "absolute", left: 0, right: 0, top: 54, display: "flex", justifyContent: "center" }}>
              <div style={{ position: "relative", width: 340, height: 340 }}>
                <div style={{ position: "absolute", inset: -18, borderRadius: "50%", border: `5px solid ${theme.colors.accent}`, opacity: 0.9 }} />
                <div style={{ position: "absolute", inset: -60, borderRadius: "50%", background: `radial-gradient(circle, ${theme.alpha(theme.colors.accent, 0.22)}, transparent 68%)` }} />
                <div style={{ position: "relative", width: 340, height: 340, borderRadius: "50%", overflow: "hidden", background: theme.colors.surfaceHi }}>
                  <Img src={staticFile("img/creator.jpg")} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${kb}) translateX(${interpolate(frame, [0, durationInFrames], [0, -8], clamp)}px)` }} />
                </div>
              </div>
            </div>
            <div style={{ position: "absolute", left: 0, right: 0, top: 440, display: "flex", justifyContent: "center", columnGap: 22 }}>
              {[{ t: tChan, l: "channel" }, { t: tPage, l: "page" }].map((c) => (
                <Entrance key={c.l} delay={c.t} from={26} config={theme.spring.snappy}>
                  <div style={{ padding: "2px 38px", borderRadius: 99, background: theme.colors.surfaceHi }}>
                    <Txt size={52} weight={theme.fonts.mid} color={theme.colors.textDim}>{c.l}</Txt>
                  </div>
                </Entrance>
              ))}
            </div>
            <div style={{ position: "absolute", left: 0, right: 0, top: 580, display: "flex", justifyContent: "center" }}>
              <Entrance delay={tFollowLine - 12} from={40} config={theme.spring.bouncy}>
                <div style={{ position: "relative", transform: `scale(${press})` }}>
                  <div style={{ position: "relative", width: 520, height: 116, borderRadius: 58, overflow: "hidden", background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <div style={{ position: "absolute", inset: 0, background: theme.colors.hero, opacity: 1 - swap, boxShadow: theme.shadow.heroGlow(0.5) }} />
                    <div style={{ position: "absolute", display: "flex", alignItems: "center", columnGap: 16, opacity: 1 - swap, transform: `translateY(${-swap * 20}px)` }}>
                      <PlusIcon size={50} color={theme.colors.white} />
                      <Txt size={62} weight={theme.fonts.heavy} color={theme.colors.white}>Follow</Txt>
                    </div>
                    <div style={{ position: "absolute", display: "flex", alignItems: "center", columnGap: 16, opacity: swap, transform: `translateY(${(1 - swap) * 20}px)` }}>
                      <CheckIcon size={50} color={theme.colors.accent} />
                      <Txt size={62} weight={theme.fonts.heavy}>Following</Txt>
                    </div>
                  </div>
                  <Tap at={tFollow} size={220} />
                </div>
              </Entrance>
            </div>
          </Glass>
        </div>
      </Entrance>
    </div>
  );
};

const Phase1: React.FC = () => {
  const ex = useExit(p2 - 10, 9);
  return (
    <div style={{ position: "absolute", left: 930, right: 90, top: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center", ...ex.style }}>
      <WordReveal text="আরও অস্থির" size={132} delay={h1} per={4} />
      <WordReveal text="tech tips" size={170} delay={h1 + 6} per={4} color={theme.colors.accent} />
      <div style={{ height: 28 }} />
      <WordReveal text="follow করে রাখুন" size={88} delay={tFollowLine} per={4} color={theme.colors.textDim} />
    </div>
  );
};

const Phase2: React.FC = () => {
  const frame = useCurrentFrame();
  const plane = interpolate(frame, [tSend, tSend + 18], [0, 1], { ...clamp, easing: theme.ease.inOut });
  const SENDX = 940, ROW_Y = 800;
  return (
    <div style={{ position: "absolute", left: 930, right: 90, top: 0, bottom: 0 }}>
      <div style={{ position: "absolute", left: 0, top: 150 }}>
        <WordReveal text="creator বন্ধুর" size={104} delay={p2} per={4} />
        <WordReveal text="উপকারে আসলে" size={104} delay={p2 + 5} per={4} color={theme.colors.textDim} />
      </div>
      <div style={{ position: "absolute", left: 0, top: 450, display: "flex", alignItems: "center", columnGap: 40 }}>
        <SweepWord delay={tShareLine} size={158}>share</SweepWord>
        <Entrance delay={tShareLine + 5} from={40} config={theme.spring.snappy}><Txt size={158} weight={theme.fonts.heavy}>করুন</Txt></Entrance>
      </div>
      {/* send button -> friends */}
      <div style={{ position: "absolute", left: 0, top: ROW_Y - 62 }}>
        <Entrance delay={tBub - 4} from={40} config={theme.spring.bouncy}>
          <div style={{ position: "relative", width: 124, height: 124, borderRadius: 62, background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.soft }}>
            <SendIcon size={56} color={theme.colors.text} />
            <Tap at={tSend} size={200} />
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 160, top: ROW_Y - 2, width: 250, height: 4, borderRadius: 2, background: `repeating-linear-gradient(90deg, ${theme.colors.textFaint} 0 14px, transparent 14px 28px)`, opacity: interpolate(frame, [tBub, tBub + 10], [0, 1], clamp) }} />
      {[0, 1, 2].map((i) => {
        const checkAt = tSend + 18 + i * 4;
        const chk = interpolate(frame, [checkAt, checkAt + 8], [0, 1], { ...clamp, easing: theme.ease.out });
        return (
          <div key={i} style={{ position: "absolute", left: 450 + i * 150, top: ROW_Y - 58 }}>
            <Entrance delay={tBub + i * 4} from={40} scaleFrom={0.7} config={theme.spring.bouncy}>
              <div style={{ position: "relative", width: 116, height: 116, borderRadius: 58, background: theme.colors.surface, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.soft }}>
                <PersonIcon size={64} color={theme.colors.textDim} />
                <div style={{ position: "absolute", right: -6, bottom: -6, width: 46, height: 46, borderRadius: 23, background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${chk})`, opacity: chk }}>
                  <CheckIcon size={28} color={theme.colors.bg} />
                </div>
              </div>
            </Entrance>
          </div>
        );
      })}
      <div style={{ position: "absolute", left: SENDX - 930 + 40 + plane * 560, top: ROW_Y - 40 - Math.sin(plane * Math.PI) * 70, opacity: plane > 0 && plane < 1 ? 1 : 0, transform: `rotate(${-8 + plane * 8}deg)` }}>
        <SendIcon size={70} color={theme.colors.accent} />
      </div>
    </div>
  );
};

export const FollowScene: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      <ProfileCard />
      {frame < p2 + 2 && <Phase1 />}
      {frame >= p2 - 2 && <Phase2 />}
    </AbsoluteFill>
  );
};

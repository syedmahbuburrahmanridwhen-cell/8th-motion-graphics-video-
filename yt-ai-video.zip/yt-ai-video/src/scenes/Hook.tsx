import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { cueStart, LEAD, scene } from "../timing";
import { clamp, Entrance, Glass, SweepWord, Txt, WordReveal, useBreathe, useFloat } from "../components/primitives";
import { LockIcon, PlayIcon, SparkleIcon, ClockIcon } from "../components/icons";
import { Bar } from "../components/devices";
import type { SfxEvent } from "../sfxTypes";

const S = scene("hook").from;
// local anchors (scene starts at global 0)
const a = 3;
const b = cueStart(2) - LEAD - S;
const c = cueStart(3) - LEAD - S;

export const hookSfx: SfxEvent[] = [
  { frame: S + a + 5, name: "thud", volume: 0.27 },
  { frame: S + b + 1, name: "whoosh_soft", volume: 0.22 },
  { frame: S + b + 14, name: "pop", volume: 0.28 },
  { frame: S + b + 20, name: "pop", volume: 0.25, rate: 1.06 },
  { frame: S + c + 9, name: "thud", volume: 0.25 },
];

/** a beat inside the scene; leaves with a scale-through */
const Beat: React.FC<{ inAt: number; outAt?: number; children: React.ReactNode }> = ({ inAt, outAt, children }) => {
  const frame = useCurrentFrame();
  if (frame < inAt - 2) return null;
  if (outAt !== undefined && frame > outAt + 10) return null;
  const p = outAt === undefined ? 0 : interpolate(frame, [outAt, outAt + 9], [0, 1], { ...clamp, easing: theme.ease.in });
  return <AbsoluteFill style={{ opacity: 1 - p, transform: `scale(${1 + 0.1 * p})` }}>{children}</AbsoluteFill>;
};

const BeatA: React.FC = () => {
  const frame = useCurrentFrame();
  const fl = useFloat(8, 34);
  const br = useBreathe(0.012, 26);
  const scan = interpolate((frame % 90) / 90, [0, 1], [-60, 160]);
  const prog = interpolate(frame, [a + 10, a + 70], [0.04, 0.62], { ...clamp, easing: theme.ease.inOut });
  return (
    <AbsoluteFill>
      <div style={{ position: "absolute", left: 140, top: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <Entrance delay={a} from={20} config={theme.spring.bouncy}>
          <Txt size={64} weight={theme.fonts.mid} color={theme.colors.textDim}>ভাই,</Txt>
        </Entrance>
        <WordReveal text="AI দিয়ে" size={215} delay={a + 5} per={5} marks={{ 0: "hero" }} />
        <WordReveal text="ভিডিও" size={215} delay={a + 12} per={5} />
        <WordReveal text="বানাতে" size={215} delay={a + 18} per={5} />
      </div>
      <div style={{ position: "absolute", left: 1010, top: 300, width: 760, height: 480 }}>
        <Entrance delay={a + 8} from={0} x={140} scaleFrom={0.9} style={{ position: "absolute", inset: 0 }}>
          <div style={{ position: "absolute", inset: 0, transform: `translate(46px, -46px) rotate(2deg)`, borderRadius: 44, background: theme.colors.surface, opacity: 0.55, boxShadow: theme.shadow.soft }} />
          <div style={{ position: "absolute", inset: 0, transform: `translateY(${fl}px) rotate(-3deg) scale(${br})` }}>
            <Glass radius={44} style={{ width: 760, height: 480 }}>
              <div style={{ position: "absolute", inset: 0, background: `radial-gradient(circle at 30% 20%, ${theme.alpha(theme.colors.accent, 0.12)}, transparent 55%)` }} />
              <div style={{ position: "absolute", top: -40, bottom: -40, width: 220, left: `${scan}%`, transform: "skewX(-18deg)", background: `linear-gradient(90deg, transparent, ${theme.alpha(theme.colors.white, 0.09)}, transparent)` }} />
              <div style={{ position: "absolute", left: "50%", top: "46%", width: 170, height: 170, marginLeft: -85, marginTop: -85, borderRadius: "50%", background: theme.alpha(theme.colors.white, 0.1), display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `inset 0 0 0 2px ${theme.alpha(theme.colors.white, 0.18)}` }}>
                <PlayIcon size={84} color={theme.colors.text} style={{ marginLeft: 8 }} />
              </div>
              <div style={{ position: "absolute", right: 36, top: 32 }}><SparkleIcon size={64} color={theme.colors.accent} style={{ transform: `rotate(${frame * 0.8}deg)` }} /></div>
              <div style={{ position: "absolute", left: 44, right: 44, bottom: 44, height: 12, borderRadius: 6, background: theme.alpha(theme.colors.white, 0.12) }}>
                <div style={{ width: `${prog * 100}%`, height: "100%", borderRadius: 6, background: theme.colors.accent }} />
              </div>
            </Glass>
          </div>
        </Entrance>
      </div>
    </AbsoluteFill>
  );
};

const PaidCard: React.FC<{ w: number; h: number; kind: "website" | "app"; delay: number }> = ({ w, h, kind, delay }) => {
  const fl = useFloat(5, 30, kind === "app" ? 2 : 0);
  return (
    <Entrance delay={delay} from={90} scaleFrom={0.9} config={theme.spring.bouncy}>
      <div style={{ transform: `translateY(${fl}px)` }}>
        <Glass radius={theme.radius.tile} style={{ width: w, height: h }}>
          {kind === "website" ? (
            <div style={{ padding: 30, display: "flex", flexDirection: "column", rowGap: 22 }}>
              <div style={{ display: "flex", columnGap: 10 }}>{[0, 1, 2].map((i) => <div key={i} style={{ width: 14, height: 14, borderRadius: 7, background: theme.colors.surfaceHi }} />)}</div>
              <Bar w="62%" h={34} /><Bar w="86%" h={20} /><Bar w="74%" h={20} />
              <div style={{ display: "flex", columnGap: 20, marginTop: 8 }}>{[0, 1, 2].map((i) => <div key={i} style={{ flex: 1, height: 120, borderRadius: 20, background: theme.colors.surfaceHi, opacity: 0.8 }} />)}</div>
            </div>
          ) : (
            <div style={{ padding: "58px 28px 28px", display: "flex", flexDirection: "column", rowGap: 22 }}>
              <div style={{ height: 150, borderRadius: 22, background: theme.colors.surfaceHi }} />
              <Bar w="80%" h={22} /><Bar w="58%" h={22} /><Bar w="70%" h={22} />
            </div>
          )}
          <div style={{ position: "absolute", inset: 0, background: theme.alpha(theme.colors.black, 0.3) }} />
          <div style={{ position: "absolute", left: "50%", top: "50%", width: 120, height: 120, marginLeft: -60, marginTop: -60, borderRadius: "50%", background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.soft }}>
            <LockIcon size={58} color={theme.colors.text} />
          </div>
          <div style={{ position: "absolute", top: 24, right: 24, padding: "6px 24px", borderRadius: 99, border: `2px solid ${theme.colors.accent}`, color: theme.colors.accent, fontFamily: theme.fonts.main, fontWeight: theme.fonts.heavy, fontSize: 40, lineHeight: 1.3 }}>paid</div>
        </Glass>
      </div>
    </Entrance>
  );
};

const BeatB: React.FC = () => (
  <AbsoluteFill>
    <div style={{ position: "absolute", top: 100, left: 0, right: 0 }}>
      <WordReveal text="paid website বা app" size={128} delay={b} per={4} align="center" marks={{ 0: "gradient" }} />
    </div>
    <div style={{ position: "absolute", top: 330, left: 0, right: 0, display: "flex", justifyContent: "center", columnGap: 64 }}>
      <PaidCard w={720} h={430} kind="website" delay={b + 10} />
      <PaidCard w={330} h={430} kind="app" delay={b + 16} />
    </div>
    <div style={{ position: "absolute", top: 836, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
      <Entrance delay={b + 30} from={30} config={theme.spring.snappy}>
        <div style={{ display: "flex", alignItems: "center", columnGap: 18, padding: "10px 40px", borderRadius: 99, background: theme.colors.surface, boxShadow: theme.shadow.soft }}>
          <ClockIcon size={46} color={theme.colors.textDim} />
          <Txt size={58} weight={theme.fonts.mid} color={theme.colors.textDim}>try করেছেন</Txt>
        </div>
      </Entrance>
    </div>
  </AbsoluteFill>
);

const BeatC: React.FC = () => {
  const br = useBreathe(0.01, 28);
  const frame = useCurrentFrame();
  const sp = (o: number) => interpolate(frame - c - o, [0, 24], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div style={{ position: "absolute", width: 1500, height: 900, background: `radial-gradient(ellipse, ${theme.alpha(theme.colors.hero, 0.13)}, transparent 62%)`, opacity: sp(0) }} />
      <div style={{ display: "flex", alignItems: "center", columnGap: 52, transform: `scale(${br})` }}>
        <Entrance delay={c} from={60} config={theme.spring.snappy}><Txt size={205} weight={theme.fonts.heavy}>এটা</Txt></Entrance>
        <SweepWord delay={c + 8} size={205}>দেখেছেন</SweepWord>
        <Entrance delay={c + 16} from={30} scaleFrom={0.55} config={theme.spring.bouncy}><Txt size={205} weight={theme.fonts.heavy}>কি?</Txt></Entrance>
      </div>
      <div style={{ position: "absolute", right: 250, top: 250, opacity: sp(22) }}><SparkleIcon size={70} color={theme.colors.accent} style={{ transform: `rotate(${frame * 0.7}deg) scale(${0.9 + Math.sin(frame / 9) * 0.1})` }} /></div>
      <div style={{ position: "absolute", left: 270, bottom: 260, opacity: sp(28) }}><SparkleIcon size={44} color={theme.colors.accent} style={{ transform: `rotate(${-frame * 0.6}deg)` }} /></div>
    </AbsoluteFill>
  );
};

export const Hook: React.FC = () => (
  <AbsoluteFill>
    <Beat inAt={a} outAt={b - 10}><BeatA /></Beat>
    <Beat inAt={b} outAt={c - 10}><BeatB /></Beat>
    <Beat inAt={c}><BeatC /></Beat>
  </AbsoluteFill>
);

import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at, cueStart, LEAD, scene } from "../timing";
import { clamp, Entrance, SweepWord, Txt, useBreathe } from "../components/primitives";
import { SparkleIcon } from "../components/icons";
import type { SfxEvent } from "../sfxTypes";

const S = scene("outro").from;
const tAvatar = 6;
const tLine1 = cueStart(21) - LEAD - S;
const tSweep = at(21, 0.22) - LEAD - S;
const tThanks = at(21, 0.78) - LEAD - S;

export const outroSfx: SfxEvent[] = [
  { frame: S + tAvatar + 2, name: "chime", volume: 0.27 },
  { frame: S + tSweep + 8, name: "pop", volume: 0.28, rate: 1.04 },
  { frame: S + tThanks + 4, name: "pop", volume: 0.24, rate: 0.96 },
];

export const OutroScene: React.FC = () => {
  const frame = useCurrentFrame();
  const br = useBreathe(0.01, 24);
  const kb = interpolate(frame, [0, scene("outro").duration], [1, 1.08], { easing: theme.ease.inOut, ...clamp });
  const halo = interpolate(frame, [tAvatar, tAvatar + 24], [0, 1], { ...clamp, easing: theme.ease.out });
  const sp = (t: number) => interpolate(frame - t, [0, 18], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <AbsoluteFill style={{ alignItems: "center" }}>
      <div style={{ position: "absolute", top: 40, width: 1100, height: 700, background: `radial-gradient(ellipse, ${theme.alpha(theme.colors.hero, 0.13)}, transparent 62%)`, opacity: halo }} />
      <div style={{ position: "absolute", top: 70 }}>
        <Entrance delay={tAvatar} from={60} scaleFrom={0.7} config={theme.spring.bouncy}>
          <div style={{ position: "relative", width: 290, height: 290, transform: `scale(${br})` }}>
            <div style={{ position: "absolute", inset: -16, borderRadius: "50%", border: `5px solid ${theme.colors.accent}` }} />
            <div style={{ position: "absolute", inset: -70, borderRadius: "50%", background: `radial-gradient(circle, ${theme.alpha(theme.colors.accent, 0.2)}, transparent 68%)` }} />
            <div style={{ position: "relative", width: 290, height: 290, borderRadius: "50%", overflow: "hidden", background: theme.colors.surfaceHi }}>
              <Img src={staticFile("img/creator.jpg")} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${kb})` }} />
            </div>
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", top: 430, display: "flex", flexDirection: "column", alignItems: "center" }}>
        <Entrance delay={tLine1} from={40} config={theme.spring.snappy}><Txt size={92} weight={theme.fonts.mid} color={theme.colors.textDim}>আমার সাথে</Txt></Entrance>
        <div style={{ display: "flex", alignItems: "center", columnGap: 44, marginTop: 4 }}>
          <SweepWord delay={tSweep} size={166}>যোগাযোগ</SweepWord>
          <Entrance delay={tSweep + 5} from={44} config={theme.spring.snappy}><Txt size={166} weight={theme.fonts.heavy}>করুন</Txt></Entrance>
        </div>
      </div>
      <div style={{ position: "absolute", top: 830 }}>
        <Entrance delay={tThanks} from={40} scaleFrom={0.9} config={theme.spring.bouncy}>
          <div style={{ display: "flex", alignItems: "center", columnGap: 22, padding: "4px 60px 4px 40px", borderRadius: 99, background: theme.colors.surface, boxShadow: theme.shadow.card }}>
            <SparkleIcon size={52} color={theme.colors.accent} style={{ transform: `rotate(${frame * 1.2}deg)` }} />
            <Txt size={96} weight={theme.fonts.heavy} color={theme.colors.accent}>ধন্যবাদ</Txt>
          </div>
        </Entrance>
      </div>
      <div style={{ position: "absolute", left: 300, top: 250, opacity: sp(tAvatar + 10) }}><SparkleIcon size={56} color={theme.colors.accent} style={{ transform: `rotate(${frame}deg)` }} /></div>
      <div style={{ position: "absolute", right: 320, top: 330, opacity: sp(tAvatar + 16) }}><SparkleIcon size={38} color={theme.colors.accent} style={{ transform: `rotate(${-frame * 0.8}deg)` }} /></div>
    </AbsoluteFill>
  );
};

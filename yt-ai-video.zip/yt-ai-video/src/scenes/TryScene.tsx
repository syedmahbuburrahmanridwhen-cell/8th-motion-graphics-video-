import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { at, LEAD, scene } from "../timing";
import { clamp, Entrance, SweepWord, Txt, WordReveal, useBreathe } from "../components/primitives";
import { ImageIcon, MusicIcon, SparkleIcon, VideoIcon } from "../components/icons";
import type { SfxEvent } from "../sfxTypes";

const S = scene("try").from;
const l1 = at(14, 0.15) - LEAD - S;
const l2 = at(14, 0.4) - LEAD - S;
const l3 = at(14, 0.55) - LEAD - S;
const chips = l3 + 8;

export const trySfx: SfxEvent[] = [
  { frame: S + l2 + 1, name: "whoosh_soft", volume: 0.22, rate: 1.05 },
  { frame: S + l3 + 9, name: "pop", volume: 0.3, rate: 1.06 },
  { frame: S + chips + 2, name: "pop", volume: 0.24, rate: 0.98 },
];

const Chip: React.FC<{ t: number; label: string; Icon: React.FC<{ size?: number; color?: string }> }> = ({ t, label, Icon }) => (
  <Entrance delay={t} from={36} scaleFrom={0.9} config={theme.spring.snappy}>
    <div style={{ display: "flex", alignItems: "center", columnGap: 20, padding: "12px 36px 12px 16px", borderRadius: 99, background: theme.colors.surface, boxShadow: theme.shadow.soft }}>
      <div style={{ width: 76, height: 76, borderRadius: 38, background: theme.colors.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center" }}><Icon size={42} color={theme.colors.accent} /></div>
      <Txt size={46} weight={theme.fonts.heavy} style={{ whiteSpace: "nowrap" }}>{label}</Txt>
    </div>
  </Entrance>
);

export const TryScene: React.FC = () => {
  const frame = useCurrentFrame();
  const br = useBreathe(0.008, 26);
  const glow = interpolate(frame, [l2, l2 + 24], [0, 1], { ...clamp, easing: theme.ease.out });
  const spark = (t: number) => interpolate(frame - t, [0, 20], [0, 1], { ...clamp, easing: theme.ease.out });
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
      <div style={{ position: "absolute", width: 1600, height: 860, background: `radial-gradient(ellipse, ${theme.alpha(theme.colors.hero, 0.14)}, transparent 62%)`, opacity: glow }} />
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", rowGap: 6, transform: `scale(${br})` }}>
        <WordReveal text="দেরি না করে" size={88} delay={l1} per={4} align="center" color={theme.colors.textDim} />
        <div style={{ display: "flex", alignItems: "center", columnGap: 52 }}>
          <Entrance delay={l2} from={60} config={theme.spring.snappy}><Txt size={218} weight={theme.fonts.heavy}>এখনই</Txt></Entrance>
          <SweepWord delay={l3} size={218}>try</SweepWord>
          <Entrance delay={l3 + 5} from={50} config={theme.spring.snappy}><Txt size={218} weight={theme.fonts.heavy}>করুন</Txt></Entrance>
        </div>
      </div>
      <div style={{ position: "absolute", top: 760, display: "flex", columnGap: 28 }}>
        <Chip t={chips} label="video" Icon={VideoIcon} />
        <Chip t={chips + 4} label="photo to video" Icon={ImageIcon} />
        <Chip t={chips + 8} label="music" Icon={MusicIcon} />
      </div>
      <div style={{ position: "absolute", left: 250, top: 250, opacity: spark(l3 + 6) }}><SparkleIcon size={64} color={theme.colors.accent} style={{ transform: `rotate(${frame * 1.1}deg)` }} /></div>
      <div style={{ position: "absolute", right: 280, top: 700 - 120, opacity: spark(l3 + 12) }}><SparkleIcon size={42} color={theme.colors.accent} style={{ transform: `rotate(${-frame}deg)` }} /></div>
    </AbsoluteFill>
  );
};

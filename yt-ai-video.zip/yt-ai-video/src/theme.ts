// theme.ts — single source of truth. Scheme: "Noir Red" (dark).
import { Easing } from "remotion";

const hex = (h: string, a: number) => {
  const n = parseInt(h.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

const colors = {
  bg: "#0B0B0D",
  bgAlt: "#131316",
  surface: "#1A1A1F",
  surfaceHi: "#24242B",
  hero: "#FF3B3B", // THE hero colour — at most one element per frame
  accent: "#FFB3A7",
  text: "#F5F5F5",
  textDim: "#9C9CA6",
  textFaint: "#5E5E68",
  white: "#FFFFFF",
  black: "#000000",
};

export const theme = {
  colors,
  alpha: hex,
  glow: hex(colors.hero, 0.42),
  line: "rgba(255,255,255,0.09)",
  fonts: {
    // one family for the whole film (Bengali + Latin subsets, bundled in public/fonts)
    main: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif",
    heavy: 700,
    mid: 600,
    body: 500,
  },
  radius: { card: 40, tile: 28, small: 18, pill: 999 },
  shadow: {
    card: "0 40px 90px -24px rgba(0,0,0,0.75), 0 0 0 1px rgba(255,255,255,0.07)",
    soft: "0 18px 50px -18px rgba(0,0,0,0.7)",
    heroGlow: (size = 1) => `0 0 ${60 * size}px ${hex(colors.hero, 0.4)}, 0 0 ${130 * size}px ${hex(colors.hero, 0.2)}`,
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  gradient: {
    hero: `linear-gradient(100deg, ${colors.hero} 0%, ${colors.accent} 100%)`,
  },
} as const;

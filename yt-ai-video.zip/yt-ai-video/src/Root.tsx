import React from "react";
import { Composition } from "remotion";
import { Main } from "./Main";
import { DURATION, } from "./timing";
import { FPS, HEIGHT, WIDTH } from "./config";

export const Root: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={DURATION} fps={FPS} width={WIDTH} height={HEIGHT} />
);

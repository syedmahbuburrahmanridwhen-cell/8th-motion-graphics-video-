// All timing derives from the SRT (cues.generated.ts). Nothing is hand-placed.
import { CUES } from "./cues.generated";
import { FPS } from "./config";

export const LEAD = 5; // visuals land ~5 frames before the related words
export const SCENE_LEAD = 12; // a scene begins this many frames before its first cue (wipe + entrance)
export const OVERLAP = 3; // outgoing scene stays this long under the wipe

const cue = (n: number) => CUES[n - 1];

/** first frame of cue n */
export const cueStart = (n: number) => Math.round(cue(n).start * FPS);
/** last frame of cue n */
export const cueEnd = (n: number) => Math.round(cue(n).end * FPS);
/** frame at fraction f (0..1) through cue n — used to place a word that sits inside a cue */
export const at = (n: number, f: number) => Math.round((cue(n).start + (cue(n).end - cue(n).start) * f) * FPS);

export const DURATION = Math.ceil(CUES[CUES.length - 1].end * FPS);

type SceneDef = { id: string; firstCue: number };

// Scene boundaries always sit on cue boundaries.
const defs: SceneDef[] = [
  { id: "hook", firstCue: 1 }, // cues 1-3
  { id: "phone", firstCue: 4 }, // cues 4-6
  { id: "carousel", firstCue: 7 }, // cues 7-9
  { id: "steps", firstCue: 10 }, // cues 10-13
  { id: "try", firstCue: 14 }, // cue 14
  { id: "follow", firstCue: 15 }, // cues 15-18
  { id: "premium", firstCue: 19 }, // cues 19-20
  { id: "outro", firstCue: 21 }, // cue 21
];

export const SCENES = defs.map((d, i) => {
  const from = i === 0 ? 0 : cueStart(d.firstCue) - SCENE_LEAD;
  return { ...d, from, to: 0, duration: 0 };
});
SCENES.forEach((s, i) => {
  const next = SCENES[i + 1];
  s.to = next ? next.from : DURATION;
  s.duration = s.to - s.from + (next ? OVERLAP : 0);
});

export const scene = (id: string) => SCENES.find((s) => s.id === id)!;

/** convert a global frame to a frame local to a scene */
export const local = (id: string, globalFrame: number) => globalFrame - scene(id).from;

/** local frame where visuals for a global frame should land (a few frames early) */
export const cueIn = (id: string, globalFrame: number) => local(id, globalFrame) - LEAD;

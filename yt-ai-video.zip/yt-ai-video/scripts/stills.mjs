// Dev helper: bundle once, render a set of key frames to out/check_<frame>.png
// Usage: node scripts/stills.mjs 30 120 175 ...   [BROWSER=/path/to/chrome]
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import path from "node:path";
import fs from "node:fs";
const frames = process.argv.slice(2).map(Number);
const browserExecutable = process.env.BROWSER || undefined;
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
const comp = await selectComposition({ serveUrl, id: "Main", browserExecutable });
fs.mkdirSync("out", { recursive: true });
for (const f of frames) {
  await renderStill({ composition: comp, serveUrl, frame: f, output: `out/check_${f}.png`, browserExecutable, overwrite: true, chromiumOptions: { gl: "angle" } });
  console.log("frame", f, "ok");
}
console.log("duration", comp.durationInFrames, "fps", comp.fps, comp.width + "x" + comp.height);

// Deterministic SFX synthesizer -> public/sfx/*.wav (16-bit mono, 44.1kHz)
// Usage: node scripts/make-sfx.mjs
import fs from "node:fs";
import path from "node:path";

const SR = 44100;
const OUT = path.resolve("public/sfx");
fs.mkdirSync(OUT, { recursive: true });

const rng = (seed) => {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return (s / 4294967296) * 2 - 1;
  };
};

// ---- RBJ biquad (coefficients can be updated while state is kept) ----
const makeBiquad = () => ({ b0: 0, b1: 0, b2: 0, a1: 0, a2: 0, x1: 0, x2: 0, y1: 0, y2: 0 });
const setBiquad = (f, type, f0, Q) => {
  const w0 = (2 * Math.PI * f0) / SR;
  const cos = Math.cos(w0);
  const alpha = Math.sin(w0) / (2 * Q);
  let b0, b1, b2;
  if (type === "lp") { b0 = (1 - cos) / 2; b1 = 1 - cos; b2 = (1 - cos) / 2; }
  else if (type === "hp") { b0 = (1 + cos) / 2; b1 = -(1 + cos); b2 = (1 + cos) / 2; }
  else { b0 = alpha; b1 = 0; b2 = -alpha; } // bp
  const a0 = 1 + alpha;
  f.b0 = b0 / a0; f.b1 = b1 / a0; f.b2 = b2 / a0;
  f.a1 = (-2 * cos) / a0; f.a2 = (1 - alpha) / a0;
};
const runBiquad = (f, x) => {
  const y = f.b0 * x + f.b1 * f.x1 + f.b2 * f.x2 - f.a1 * f.y1 - f.a2 * f.y2;
  f.x2 = f.x1; f.x1 = x; f.y2 = f.y1; f.y1 = y;
  return y;
};
const filterBuffer = (buf, type, f0, Q = 0.707) => {
  const f = makeBiquad();
  setBiquad(f, type, f0, Q);
  return buf.map((x) => runBiquad(f, x));
};

// ---- small room reverb (synthetic IR, ~70ms) ----
const reverb = (buf, wet = 0.12, ms = 70, seed = 7) => {
  const n = Math.floor((ms / 1000) * SR);
  const r = rng(seed);
  const ir = new Float32Array(n);
  for (let i = 0; i < n; i++) ir[i] = r() * Math.exp((-6.9 * i) / n);
  const lpIr = filterBuffer(Array.from(ir), "lp", 3500);
  const out = new Float32Array(buf.length);
  for (let i = 0; i < buf.length; i++) {
    let acc = 0;
    const lim = Math.min(n, i + 1);
    for (let k = 0; k < lim; k += 3) acc += buf[i - k] * lpIr[k];
    out[i] = buf[i] * (1 - wet * 0.5) + acc * wet * 0.35;
  }
  return Array.from(out);
};

const finish = (buf, seconds, fadeMs = 25) => {
  const n = Math.floor(seconds * SR);
  const out = new Array(n).fill(0);
  for (let i = 0; i < n && i < buf.length; i++) out[i] = buf[i];
  const fade = Math.floor((fadeMs / 1000) * SR);
  for (let i = 0; i < fade; i++) out[n - 1 - i] *= i / fade;
  return out;
};

const smoothstep = (x) => { x = Math.min(1, Math.max(0, x)); return x * x * (3 - 2 * x); };

// ---------------- sound designs ----------------
const pop = () => {
  const len = 0.3, n = Math.floor(len * SR);
  const b = new Array(n);
  let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const f = 190 + 420 * Math.exp(-t / 0.035); // fast downward pitch
    ph += (2 * Math.PI * f) / SR;
    const env = Math.min(1, t / 0.004) * Math.exp(-t / 0.055);
    b[i] = Math.sin(ph) * env;
  }
  return finish(reverb(filterBuffer(b, "lp", 3200)), 0.26);
};

const click = () => {
  const len = 0.16, n = Math.floor(len * SR);
  const r = rng(11);
  const b = new Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    b[i] = r() * Math.min(1, t / 0.0012) * Math.exp(-t / 0.011);
  }
  let x = filterBuffer(b, "hp", 2200, 0.8);
  x = filterBuffer(x, "lp", 7000);
  const pk = Math.max(...x.map(Math.abs));
  x = x.map((v) => Math.tanh((v / pk) * 2.6)); // soft-limit: lowers crest factor so level matches the others
  x = filterBuffer(x, "lp", 6500);
  return finish(reverb(x, 0.08, 40), 0.14, 15);
};

const whoosh = (seconds, f0, f1, Q, seed, attack = 0.38) => {
  const n = Math.floor(seconds * SR);
  const r = rng(seed);
  const f = makeBiquad();
  const b = new Array(n);
  for (let i = 0; i < n; i++) {
    if (i % 32 === 0) {
      const p = smoothstep(i / n);
      setBiquad(f, "bp", f0 * Math.pow(f1 / f0, p), Q); // sweep
    }
    const p = i / n;
    const env = smoothstep(p / attack) * (1 - smoothstep((p - attack) / (1 - attack)));
    b[i] = runBiquad(f, r()) * env;
  }
  return finish(reverb(filterBuffer(b, "lp", 5200), 0.1, 60), seconds - 0.01, 40);
};

const chime = () => {
  const len = 0.6, n = Math.floor(len * SR);
  const f0 = 784; // G5, soft
  const partials = [
    [1, 1.0, 0.2], [2.0, 0.32, 0.13], [3.01, 0.12, 0.085], [4.2, 0.05, 0.05],
  ];
  const b = new Array(n).fill(0);
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    let s = 0;
    for (const [ratio, amp, tau] of partials) s += Math.sin(2 * Math.PI * f0 * ratio * t) * amp * Math.exp(-t / tau);
    b[i] = s * Math.min(1, t / 0.004);
  }
  return finish(reverb(filterBuffer(b, "lp", 5000), 0.14, 80), 0.5, 40);
};

const thud = () => {
  const len = 0.34, n = Math.floor(len * SR);
  const b = new Array(n);
  let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    const f = 46 + 70 * Math.exp(-t / 0.05);
    ph += (2 * Math.PI * f) / SR;
    b[i] = Math.sin(ph) * Math.min(1, t / 0.006) * Math.exp(-t / 0.075);
  }
  return finish(reverb(filterBuffer(b, "lp", 420), 0.08, 50), 0.3);
};

const sounds = {
  pop: pop(),
  click: click(),
  whoosh: whoosh(0.7, 380, 3400, 0.9, 21, 0.4),
  whoosh_soft: whoosh(0.45, 300, 1900, 0.8, 33, 0.35),
  chime: chime(),
  thud: thud(),
};

// ---------------- level matching + export ----------------
const TARGET_RMS = 0.11, PEAK_CEIL = 0.85;
const rms = (b) => Math.sqrt(b.reduce((s, x) => s + x * x, 0) / b.length);
const peak = (b) => b.reduce((m, x) => Math.max(m, Math.abs(x)), 0);
const dB = (x) => (20 * Math.log10(x || 1e-9)).toFixed(1);

const wav = (b) => {
  const data = Buffer.alloc(b.length * 2);
  b.forEach((x, i) => data.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x)) * 32767), i * 2));
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8);
  h.write("fmt ", 12); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(SR, 24); h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34);
  h.write("data", 36); h.writeUInt32LE(data.length, 40);
  return Buffer.concat([h, data]);
};

console.log("name         dur(s)  peak(dB)  rms(dB)  clipped");
for (const [name, raw] of Object.entries(sounds)) {
  let g = TARGET_RMS / rms(raw);
  if (peak(raw) * g > PEAK_CEIL) g = PEAK_CEIL / peak(raw);
  const out = raw.map((x) => x * g);
  fs.writeFileSync(path.join(OUT, `${name}.wav`), wav(out));
  const clipped = out.filter((x) => Math.abs(x) >= 0.999).length;
  console.log(`${name.padEnd(12)} ${(out.length / SR).toFixed(2).padStart(5)}  ${dB(peak(out)).padStart(7)}  ${dB(rms(out)).padStart(7)}  ${clipped}`);
}

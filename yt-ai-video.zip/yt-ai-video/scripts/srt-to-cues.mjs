// SRT -> src/cues.generated.ts  (the SRT is the ONLY source of timing)
// Usage: node scripts/srt-to-cues.mjs
import fs from "node:fs";
const raw = fs.readFileSync("public/script.srt", "utf8").replace(/\r/g, "");
const toSec = (t) => {
  const [h, m, rest] = t.split(":");
  const [s, ms] = rest.split(",");
  return +h * 3600 + +m * 60 + +s + +ms / 1000;
};
const cues = raw.trim().split(/\n\s*\n/).map((block) => {
  const lines = block.split("\n");
  const [a, b] = lines[1].split(" --> ");
  return { index: +lines[0], start: toSec(a.trim()), end: toSec(b.trim()), text: lines.slice(2).join(" ") };
});
fs.writeFileSync(
  "src/cues.generated.ts",
  `// AUTO-GENERATED from public/script.srt by scripts/srt-to-cues.mjs — do not edit by hand\nexport type Cue = { index: number; start: number; end: number; text: string };\nexport const CUES: Cue[] = ${JSON.stringify(cues, null, 2)};\n`
);
console.log(`${cues.length} cues, ends at ${cues.at(-1).end}s`);
